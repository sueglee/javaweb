package com.wu.service.role;


import com.wu.pojo.Role;

import java.util.List;

public interface RoleService {
    /**
     * 获取角色列表
     *
     * @return
     */
    public List<Role> getRoleList();

}
