package com.yc.po;

public class BillPro extends Bill {
	private String proname;

	public String getProname() {
		return proname;
	}

	public void setProname(String proname) {
		this.proname = proname;
	}
	
}
